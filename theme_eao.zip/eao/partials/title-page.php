<div class="title-page">
	<div class="large-10 large-centered">
		<h1>
			<?php the_title(); ?>
		</h1>
	</div>
</div>