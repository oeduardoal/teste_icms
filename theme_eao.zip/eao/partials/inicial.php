<div class="header-menu">
	<div class="row">
		<div class="large-12 columns large-centered text-center">
			<h3><a href="<?php echo site_url(); ?>"><?php bloginfo(); ?></a></h3>
		</div>
	</div>
</div>
