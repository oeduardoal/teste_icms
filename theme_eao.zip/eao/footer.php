	</body>
	<footer><?php wp_footer(); ?></footer>
</html>